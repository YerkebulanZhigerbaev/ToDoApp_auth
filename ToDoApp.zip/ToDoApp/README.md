# ToDo app




<h2>Installation</h2>

```
pip3 install  django
pip3 install postgresql
pip3 install  psycopg2-binary


```

<h2>Usage </h2>

```

```

<h2>Examples</h2>
Firstly you should pass the registration and then log in to the system. After this, you can use this app. There are 3 functions: create task, delete task, update task.
